desc user;
select * from user;